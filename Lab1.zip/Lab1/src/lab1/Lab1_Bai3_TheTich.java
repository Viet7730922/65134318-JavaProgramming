package lab1;

import java.util.Scanner;

public class Lab1_Bai3_TheTich {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// Nhap do dai canh cua khoi lap phuong
		double side_lenght = 0;
		do {
			System.out.print("Nhập độ dài cạnh khối lập phương (số thập phân): ");
			side_lenght = sc.nextDouble();
		} while (side_lenght < 0);
		double volume_cube = TinhTheTichLapPhuong(side_lenght);
		
		// In ra ket qua the tich cua khoi lap phuong
		System.out.printf("\nThể tích của khối lập phương có độ dài cạnh"
				+ " là %.2f bằng %.2f",side_lenght,volume_cube);
		
		sc.close();
	}
	public static double TinhTheTichLapPhuong(double cube) {
		double volume_cube = 0;
		volume_cube = Math.pow(cube, 3);
		return volume_cube;
	}
}

