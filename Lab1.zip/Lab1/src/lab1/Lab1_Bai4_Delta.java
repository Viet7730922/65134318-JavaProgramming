package lab1;

import java.util.Scanner;

public class Lab1_Bai4_Delta {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Chương trình tính Delta phương trình bậc 2 (ax^2 + bx + c = 0)");
        
        // Nhap he so a, b, c
        System.out.print("Nhập hệ số a: ");
        double a = sc.nextDouble();

        System.out.print("Nhập hệ số b: ");
        double b = sc.nextDouble();

        System.out.print("Nhập hệ số c: ");
        double c = sc.nextDouble();

        // Tinh Delta: b^2 - 4*a*c
        double delta = Math.pow(b, 2) - 4 * a * c;

        // In ra ket qua
        System.out.printf("Delta = %.2f\n", delta);

        // Kiem tra dieu kien cua Delta
        if (delta < 0) {
            System.out.println("Delta < 0 nên không có căn bậc hai thực.");
        } else {
            double canDelta = Math.sqrt(delta);
            System.out.printf("Căn bậc hai của Delta = %.2f\n", canDelta);
        }

        sc.close();
    }
}
