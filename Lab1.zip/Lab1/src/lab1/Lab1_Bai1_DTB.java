package lab1;

import java.util.Scanner;

public class Lab1_Bai1_DTB {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// Nhap Ho va Ten Sinh Vien
		System.out.print("Nhập họ và tên sinh viên: ");
		String studentName= sc.nextLine();
		
		// Nhap Diem trung binh cua sinh vien
		double studentPoint = 0;
		do {
			System.out.print("Nhập điểm trung bình của sinh viên: ");
			studentPoint = sc.nextDouble();
		} while (studentPoint < 0); 
		
		// In ra man hinh
		for(int i=0; i < 37; i++) {System.out.print("=");}
		System.out.print("\nHọ và Tên sinh viên: "+studentName);
		System.out.printf("\nĐiểm trung bình của sinh viên: %.2f",studentPoint);		
		
		sc.close();
		
	}
}
