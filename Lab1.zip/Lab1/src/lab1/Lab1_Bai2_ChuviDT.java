package lab1;

import java.util.Scanner;

public class Lab1_Bai2_ChuviDT {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		// Nhap canh a va b (thu nhat va thu hai)
		double a, b = 0;
		do {
			System.out.print("Nhập độ dài cạnh thứ nhất: ");
			a = sc.nextDouble();
		} while (a < 0);
		
		do {
			System.out.print("Nhập độ dài cạnh thứ hai: ");
			b = sc.nextDouble();
		} while (b < 0);
		
		double chuVi_CN = 2 * (a + b);
		double dienTich_CN = a * b;
		double min_side = 0;
		if (a < b) {
			min_side = a;
		} else min_side = b;
		// In ra man hinh cac ket qua tinh cua hinh chu nhat
		for(int i=0; i < 37; i++) {System.out.print("=");}
		System.out.printf("\nChu vi: %.2f\n"
				+ "Diện tích: %.2f\n"
				+ "Cạnh nhỏ của hình chữ nhật là: %.2f", chuVi_CN, dienTich_CN, min_side);
		
		sc.close();
	}
}
