package BaiTap1;

import java.util.Scanner;

public class BaiTap1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhập một thông điệp: ");
		String message = sc.nextLine();
		
		System.out.println("\nNội dung thông điệp: "+message);
		System.out.print("\nHọ và Tên sinh viên: Võ Quốc Việt.\n"
				+ "Thuộc lớp: 65.CNTT-1.\n"
				+"Số điện thoại liên lạc: 0846.103.268\n"
				+"Email NTU: viet.vq.65cntt@ntu.edu.vn");
		sc.close();
	}
}
