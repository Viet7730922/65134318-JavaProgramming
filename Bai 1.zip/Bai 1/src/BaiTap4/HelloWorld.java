package BaiTap4;

public class HelloWorld {
    public static void main(String[] args) {
        // Text blocks với """
        String greeting = """
            ===========================
            HELLO, MODERN JAVA!
            ===========================
            by Student Võ Quốc Việt NTU
            ===========================
                       *
                      ***
                     *****
                    *******
                   *********
           *************************
             *********************
               *****************
                 *************
                ******   ******
               *****       *****
              ***             ***
             *                   *
            """;
        System.out.println(greeting);
        
        // var - tự động suy luận kiểu
        var message = "Hello, World with var!";
        var number = 79;
        var list = java.util.List.of("Java", "Modern", "Features");
        
        System.out.println(message);
        System.out.println("Number: " + number);
        System.out.println("List: " + list);
    }
}