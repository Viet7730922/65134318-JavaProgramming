package baiTap3;

import java.util.Scanner;

public class TinhToan {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        try {
            // Nhap phep toan
            System.out.print("Nhap phep toan can tinh (1 - Cong; 2 - Tru; 3 - Nhan; 4 - Chia): ");
            int n = sc.nextInt();
            
            // Kiem tra nhap
            while (n < 1 || n > 4) {
                System.out.print("Nhap lai phep toan (1 - Cong; 2 - Tru; 3 - Nhan; 4 - Chia): ");
                n = sc.nextInt();
            }

            // Nhap so nguyen a va b
            System.out.print("Nhap so nguyen thu nhat (a): ");
            int a = sc.nextInt();
            System.out.print("Nhap so nguyen thu hai (b): ");
            int b = sc.nextInt();

            // Goi ham Tinh Toan
            TinhToan tt = new TinhToan();
            int ketQua = tt.PhepTinh(a, b, n);

            //
            if (n == 4 && b == 0) {
                // Bao loi phep tinh khong the thuc hien phep chia cho 0 da thuc tinh trong ham
            } else {
            	String pt = "";
            	switch (n) {
					case 1: pt = "Cong"; break;
					case 2: pt = "Tru"; break;
					case 3: pt = "Nhan"; break;
					case 4: pt = "Chia"; break;
				}
                System.out.println("Ket qua phep "+pt+" la: " + ketQua);
            }

        } catch (Exception e) {
            System.out.println("Loi nhap lieu: Ban phai nhap so nguyen!");
        } finally {
            sc.close(); // Dong scanner
        }
    }

    // Ham thuc hien phep tinh
    int PhepTinh(int a, int b, int k) {
        int ketQua = 0;
        switch (k) {
            case 1: // Cong
                ketQua = a + b;
                break;
            case 2: // Tru
                ketQua = a - b;
                break;
            case 3: // Nhan
                ketQua = a * b;
                break;
            case 4: // Chia
                if (b == 0) {
                    System.out.println("Loi: Khong the chia cho 0!");
                    return 0; // Khong the chia cho 0
                } else {
                    ketQua = a / b; 
                }
                break;
        }
        return ketQua;
    }
}