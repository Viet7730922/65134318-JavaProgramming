package helloWorld;

public class HelloWorldJava {
	public static void main(String[] args) {
		System.out.print("Xin chào thế giới Java 2026 - Năm Bính Ngọ!");
		System.out.print("\n\t\t\t- Vo Quoc Viet -");		
	}
}
