package baiTap2;

import java.util.Scanner;

public class QuyDoiTienTe {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        final double TY_GIA = 26243; //Tỷ giá dựa vào ngày 23/ 1/ 2026
        int s = 0;
        do {
        	System.out.println("Chọn mệnh giá tiền cần quy đổi "
        			+ "(1 - USD sang VND; 2 - VND sang USD): ");
        	s = sc.nextInt();
        } while( s < 1 || s > 2);
        
        double vnd = 0;
        double usd = 0;
        switch (s) {
			case 1: {
		        System.out.println("Nhập số tiền USD cần đổi: ");
		        usd = sc.nextDouble();
		        vnd = usd * TY_GIA;
		        break;
			}
			case 2: {
		        System.out.println("Nhập số tiền VND cần đổi: ");
		        vnd = sc.nextDouble();
		        usd = vnd / TY_GIA;
		        break;
			}
        }
		
        System.out.println("--- KẾT QUẢ ---");
        System.out.println("Theo Tỷ giá theo ngày 23/ 1/ 2026: 1 USD = 26,243 VNĐ.");
        if(s==1) {
        	System.out.printf("%.2f USD = %,.0f VNĐ", usd, vnd);
        } else {System.out.printf("%,.0f USD = %.2f USD", vnd, usd);}
        
        sc.close();
    }
}
