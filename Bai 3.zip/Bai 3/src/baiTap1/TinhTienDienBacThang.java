package baiTap1;

import java.util.Scanner;

public class TinhTienDienBacThang {
	public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhập số điện tiêu thụ (kWh): ");
        double soDien = sc.nextDouble();
        double tienDien = 0;

        // Bảng giá điện 6 bậc (Dựa theo mức giá điện được phê duyệt vào ngày 10/5/2025)
        final double GIA_BAC_1 = 1984;
        final double GIA_BAC_2 = 2050;
        final double GIA_BAC_3 = 2380;
        final double GIA_BAC_4 = 2998;
        final double GIA_BAC_5 = 3350;
        final double GIA_BAC_6 = 3460;

        // Các mốc giới hạn số điện
        final int MOC_1 = 50;
        final int MOC_2 = 100;
        final int MOC_3 = 200;
        final int MOC_4 = 300;
        final int MOC_5 = 400;

        if (soDien <= MOC_1) {
            tienDien = soDien * GIA_BAC_1;
        } else if (soDien <= MOC_2) {
            tienDien = (MOC_1 * GIA_BAC_1) 
                     + ((soDien - MOC_1) * GIA_BAC_2);
        } else if (soDien <= MOC_3) {
            tienDien = (MOC_1 * GIA_BAC_1) 
                     + ((MOC_2 - MOC_1) * GIA_BAC_2) 
                     + ((soDien - MOC_2) * GIA_BAC_3);
        } else if (soDien <= MOC_4) {
            tienDien = (MOC_1 * GIA_BAC_1) 
                     + ((MOC_2 - MOC_1) * GIA_BAC_2) 
                     + ((MOC_3 - MOC_2) * GIA_BAC_3) 
                     + ((soDien - MOC_3) * GIA_BAC_4);
        } else if (soDien <= MOC_5) {
            tienDien = (MOC_1 * GIA_BAC_1) 
                     + ((MOC_2 - MOC_1) * GIA_BAC_2) 
                     + ((MOC_3 - MOC_2) * GIA_BAC_3) 
                     + ((MOC_4 - MOC_3) * GIA_BAC_4)
                     + ((soDien - MOC_4) * GIA_BAC_5);
        } else { // Bậc 6
            tienDien = (MOC_1 * GIA_BAC_1) 
                     + ((MOC_2 - MOC_1) * GIA_BAC_2) 
                     + ((MOC_3 - MOC_2) * GIA_BAC_3) 
                     + ((MOC_4 - MOC_3) * GIA_BAC_4)
                     + ((MOC_5 - MOC_4) * GIA_BAC_5)
                     + ((soDien - MOC_5) * GIA_BAC_6);
        }

        System.out.println("---------------------------------");
        System.out.printf("Số điện tiêu thụ: %.1f kWh\n", soDien);
        System.out.printf("Tổng tiền chưa thuế: %,.0f VNĐ\n", tienDien);
//        
//        double thueGTGT = tienDien * 0.08; // Thuế 8%
//        System.out.printf("Thuế GTGT (8%%): %,.0f VNĐ\n", thueGTGT);
//        System.out.printf("TỔNG THANH TOÁN: %,.0f VNĐ", tienDien + thueGTGT);
        
        sc.close();
    }
}
