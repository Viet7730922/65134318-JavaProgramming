package baiTap3;

import java.io.*; 
import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class NhatKy {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String tenFile = "nhatky.txt";
        
        while (true) {
            System.out.println("\n--- NHẬT KÝ CÁ NHÂN ---");
            System.out.println("1. Viết nhật ký mới");
            System.out.println("2. Đọc lại nhật ký cũ");
            System.out.println("3. Thoát");
            System.out.print("Chọn chức năng (1-3): ");
            int chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    ghiFile(tenFile, sc);
                    break;
                case 2:
                    docFile(tenFile);
                    break;
                case 3:
                    System.out.println("Chấm bút và tạm biệt.");
                    return; 
                default:
                    System.out.println("Vui lòng chọn lại!");
            }
        }
    }

    // Ghi file
    public static void ghiFile(String fileName, Scanner sc) {
        try {
            FileWriter fw = new FileWriter(fileName, true); 
            BufferedWriter bw = new BufferedWriter(fw);
            
            // Lấy ngày/tháng/năm giờ/phút/giây hiện tại
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter fm = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
            String thoiGian = now.format(fm);

            System.out.print("Nội dung nhật ký hôm nay: ");
            String noiDung = sc.nextLine();

            // Ghi vào file
            bw.write("[" + thoiGian + "] " + noiDung);
            bw.newLine(); // Xuống dòng cho lần ghi sau
            
            bw.close(); // Đóng file
            System.out.println(">> Đã lưu nhật ký thành công!");
        } catch (IOException e) {
            System.out.println("Lỗi khi ghi file: " + e.getMessage());
        }
    }

    // Đọc file
    public static void docFile(String fileName) {
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                System.out.println(">> Bạn chưa có dòng nhật ký nào!");
                return;
            }

            Scanner fileScanner = new Scanner(file);
            System.out.println("\n--- NỘI DUNG NHẬT KÝ ---");
            while (fileScanner.hasNextLine()) {
                String data = fileScanner.nextLine();
                System.out.println(data);
            }
            fileScanner.close();
        } catch (FileNotFoundException e) {
            System.out.println("Không tìm thấy file.");
        }
    }
}
