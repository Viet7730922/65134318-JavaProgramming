package baiTap3;
import java.util.Scanner;

public class GiaiPhuongTrinhBacMot {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Nhap so thap phan a va b
            System.out.println("Nhập a: ");
            double a = scanner.nextDouble();

            System.out.println("Nhập b: ");
            double b = scanner.nextDouble();

            // Giai phuong trinh
            if (a == 0) {
                if (b == 0) {
                    System.out.println("Phương trình có vô số nghiệm.");
                } else {
                    System.out.println("Phương trình vô nghiệm.");
                }
            } else {
            	double k = -b/a;
                double x = (k!=0) ? k : 0; //Fix lỗi x = -0.00 nếu b = 0.
                System.out.printf("Nghiệm của phương trình: x = %.2f\n", x);
            }
        } catch (Exception e) {
            System.out.println("Vui lòng nhập lại.");
        } finally {
            scanner.close();
        }
    }
}
