package BaiTap1;

import java.util.Scanner;

public class TinhTienLuong {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Nhap so gio lam va muc luong theo gio
            System.out.print("Nhập số giờ làm: ");
            int hours = scanner.nextInt();

            System.out.print("Nhập lương theo giờ: ");
            double hourlyWage = scanner.nextDouble();

            // Kiem tra luong theo gio va tong luong khi vuot qua gio
            double totalSalary;
            if (hours > 40) {
                int overtimeHours = hours - 40; // Số giờ vượt quá 40
                totalSalary = 40 * hourlyWage + overtimeHours * hourlyWage * 1.5;
            } else {
                totalSalary = hours * hourlyWage;
            }

            // In ra man hinh tong luong theo gio
            System.out.printf("Tổng lương: %.2f VND\n", totalSalary);
        } catch (Exception e) {
            System.out.println("Lỗi nhập liệu. Vui lòng nhập số hợp lệ.");
        } finally {
            scanner.close();
        }
    }
}
