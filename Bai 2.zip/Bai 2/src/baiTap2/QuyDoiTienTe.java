package baiTap2;

import java.util.Scanner;

public class QuyDoiTienTe {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        try {
        	System.out.println("Nhập số tiền USD: ");
        	double usd = sc.nextDouble();
        	
        	System.out.println("Nhập số tiền EUR: ");
        	double eur = sc.nextDouble();
        	
        	double vndFromUsd = usd * 23500;
        	double vndFromEur = eur * 27000;
        	
        	System.out.printf("%.2f$ chuyển đổi được %.2f VND\n", usd,vndFromUsd);
        	System.out.printf("%.2f€ chuyển đổi được %.2f VND\n", eur,vndFromEur);
        } catch (Exception e) {
			System.out.print("Lỗi nhập liệu. Vui lòng nhập lại.");
		} finally {
			sc.close();
		}
    }
}